import time
import os
import pandas as pd
from sklearn.ensemble import IsolationForest

# 1. SETUP AI MODEL (Training)
# We train it to know that 1-2 blocks per minute is normal
df = pd.DataFrame({"blocks": [1, 0, 2, 1, 0, 1, 2, 0, 1, 1]})
model = IsolationForest(contamination=0.1).fit(df)

LOG_FILE = "/var/log/pfsense.log"

print(f"--- LIVE AI WATCHDOG ACTIVE ---")
print(f"Watching: {LOG_FILE}")

def monitor_logs():
    # Create the log file if it doesn't exist yet
    if not os.path.exists(LOG_FILE):
        open(LOG_FILE, 'a').close()
        os.chmod(LOG_FILE, 0o666)

    # Open the file and go to the end
    with open(LOG_FILE, "r") as f:
        f.seek(0, 2)
        while True:
            line = f.readline()
            if not line:
                time.sleep(1)
                continue
            
            # THE LOGIC: Look for 'filterlog' (pfSense's block log)
            if "filterlog" in line:
                print(f"[NEW LOG]: {line.strip()[:80]}...")
                
                # In a real system, we would count blocks per minute
                # For this demo, we'll trigger an anomaly if we see a specific pattern
                # Let's simulate: if we see a log, we treat it as '10' blocks to trigger the AI
                prediction = model.predict([[10]]) 
                
                if prediction[0] == -1:
                    print(">>> !!! AI ALERT: ANOMALOUS TRAFFIC BLOCKED !!!")
                    print(">>> Action: Monitoring source for potential Brute Force.")

if __name__ == "__main__":
    monitor_logs()
