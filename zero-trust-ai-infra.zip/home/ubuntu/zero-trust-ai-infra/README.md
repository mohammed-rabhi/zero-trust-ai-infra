# Projet : Infrastructure d'Entreprise Zéro Confiance et IA

## Vue d'ensemble du projet

Ce projet démontre la conception, la mise en œuvre et l'automatisation d'une infrastructure réseau et serveur de niveau entreprise, sécurisée et observable, dans un environnement de laboratoire virtuel. Il met l'accent sur les principes de la **Zéro Confiance (Zero-Trust)**, l'**Infrastructure as Code (IaC)** et la **surveillance et la journalisation complètes** avec une touche d'**Intelligence Artificielle (IA)** pour la détection d'anomalies en temps réel.

L'objectif est de présenter des compétences avancées en ingénierie des systèmes et des réseaux, en allant au-delà des configurations de base pour construire un écosystème résilient, sécurisé et évolutif.

## Fonctionnalités Clés

*   **Réseau Zéro Confiance :** Segmentation VLAN granulaire, règles de pare-feu strictes et isolation des réseaux pour les utilisateurs, les serveurs et la gestion.
*   **Infrastructure as Code (IaC) :** Déploiement automatisé de l'infrastructure virtuelle (machines virtuelles, conteneurs) à l'aide de Terraform.
*   **Gestion de la Configuration :** Automatisation de la configuration des systèmes et des pare-feu à l'aide d'Ansible.
*   **Sécurité Périmétrique :** Utilisation de pfSense comme pare-feu de nouvelle génération (NGFW) pour le routage, le filtrage et la journalisation centralisée.
*   **Détection d'Anomalies par IA :** Un système de surveillance Python basé sur l'apprentissage automatique (Isolation Forest) qui analyse les journaux de pfSense en temps réel pour détecter les activités suspectes (par exemple, les tentatives de force brute).
*   **Gestion Hors Bande (OOB) :** Accès sécurisé et isolé aux nœuds de gestion via un adaptateur Host-Only pour une administration fiable.

## Architecture du Projet

Le diagramme suivant illustre l'architecture logique de l'infrastructure :

```d2
direction: right

Host_Laptop: "Ordinateur Hôte (Windows)" {
  shape: rectangle
  style: { fill: "#e0f2f7", stroke: "#00796b", stroke-width: 2px }
  
  VirtualBox: "Oracle VirtualBox" {
    shape: rectangle
    style: { fill: "#e0f2f7", stroke: "#00796b", stroke-width: 1px }

    HostOnly: "Adaptateur Host-Only" {
      shape: cylinder
      style: { fill: "#fff3e0", stroke: "#e65100" }
      label: "192.168.56.1/24"
    }

    Internal_Network: "Réseau Interne (LAB_MGMT)" {
      shape: cylinder
      style: { fill: "#e8f5e9", stroke: "#2e7d32" }
      label: "192.168.1.0/24"
    }

    NAT_Network: "Réseau NAT (Internet)" {
      shape: cylinder
      style: { fill: "#f3e5f5", stroke: "#4a148c" }
      label: "Accès Internet"
    }

    VM_pfSense: "pfSense-FW" {
      shape: rectangle
      style: { fill: "#ffebee", stroke: "#c62828" }
      label: "Pare-feu NGFW"

      pfSense_WAN: "em0 (WAN)" { shape: circle; style: { fill: "#f3e5f5" } }
      pfSense_LAN: "em1 (LAN)" { shape: circle; style: { fill: "#e8f5e9" } }
      pfSense_SERVERS: "em2 (SERVERS)" { shape: circle; style: { fill: "#e8f5e9" } }
      pfSense_USERS: "em3 (USERS)" { shape: circle; style: { fill: "#e8f5e9" } }
    }

    VM_MGMT: "MGMT-Server (Ubuntu)" {
      shape: rectangle
      style: { fill: "#e3f2fd", stroke: "#1565c0" }
      label: "Contrôleur d'Automatisation & IA"

      MGMT_ETH0: "enp0s3 (LAB_MGMT)" { shape: circle; style: { fill: "#e8f5e9" } }
      MGMT_ETH1: "enp0s8 (Host-Only)" { shape: circle; style: { fill: "#fff3e0" } }
    }

    VM_SERVERS: "SERVERS-VM (Ubuntu)" {
      shape: rectangle
      style: { fill: "#fbe9e7", stroke: "#bf360c" }
      label: "Serveurs d'Applications"

      SERVERS_ETH0: "enp0s3 (LAB_SERVERS)" { shape: circle; style: { fill: "#e8f5e9" } }
    }

    VM_USERS: "USERS-VM (Ubuntu)" {
      shape: rectangle
      style: { fill: "#fce4ec", stroke: "#ad1457" }
      label: "Postes Clients (Utilisateurs)"

      USERS_ETH0: "enp0s3 (LAB_USERS)" { shape: circle; style: { fill: "#e8f5e9" } }
    }
  }
}

Host_Laptop.VirtualBox.NAT_Network -> Host_Laptop.VirtualBox.VM_pfSense.pfSense_WAN: "Internet"
Host_Laptop.VirtualBox.VM_pfSense.pfSense_LAN -> Host_Laptop.VirtualBox.Internal_Network: "192.168.1.1"
Host_Laptop.VirtualBox.Internal_Network -> Host_Laptop.VirtualBox.VM_MGMT.MGMT_ETH0: "192.168.1.100"
Host_Laptop.VirtualBox.VM_MGMT.MGMT_ETH1 -> Host_Laptop.VirtualBox.HostOnly: "192.168.56.101"
Host_Laptop.VirtualBox.HostOnly -> Host_Laptop: "Accès OOB SSH"

Host_Laptop.VirtualBox.VM_pfSense.pfSense_SERVERS -> Host_Laptop.VirtualBox.VM_SERVERS.SERVERS_ETH0: "10.0.20.0/24"
Host_Laptop.VirtualBox.VM_pfSense.pfSense_USERS -> Host_Laptop.VirtualBox.VM_USERS.USERS_ETH0: "10.0.30.0/24"

linkStyle 0 stroke: "#4a148c", stroke-width: 2px
linkStyle 1 stroke: "#2e7d32", stroke-width: 2px
linkStyle 2 stroke: "#2e7d32", stroke-width: 2px
linkStyle 3 stroke: "#e65100", stroke-width: 2px
linkStyle 4 stroke: "#bf360c", stroke-width: 2px
linkStyle 5 stroke: "#ad1457", stroke-width: 2px
```

## Technologies Utilisées

*   **Virtualisation :** Oracle VirtualBox
*   **Pare-feu/Routage :** pfSense CE
*   **Système d'Exploitation :** Ubuntu Server LTS
*   **Infrastructure as Code (IaC) :** Terraform
*   **Gestion de la Configuration :** Ansible
*   **Conteneurisation :** Docker
*   **Détection d'Anomalies :** Python (scikit-learn, pandas, numpy) avec algorithme Isolation Forest
*   **Journalisation Centralisée :** rsyslog

## Guide de Mise en Place (Étape par Étape)

### Prérequis

*   Un ordinateur hôte (Windows, macOS, Linux) avec Oracle VirtualBox installé.
*   Images ISO : pfSense CE, Ubuntu Server LTS.

### 1. Configuration du Réseau Virtuel et Déploiement de pfSense

1.  **Créer les Réseaux Internes VirtualBox :** `LAB_MGMT`, `LAB_SERVERS`, `LAB_USERS` (définis lors de la configuration des cartes réseau des VMs).
2.  **Déployer pfSense-FW :**
    *   Créer une VM avec 4 cartes réseau : `NAT` (WAN), `LAB_MGMT` (LAN), `LAB_SERVERS` (OPT1), `LAB_USERS` (OPT2).
    *   Installer pfSense (choisir UFS/GPT).
    *   Configurer les interfaces dans pfSense : `em0` (WAN), `em1` (LAN - `192.168.1.1/24`), `em2` (SERVERS - `10.0.20.1/24`), `em3` (USERS - `10.0.30.1/24`).
    *   Activer les serveurs DHCP pour `LAN`, `SERVERS` et `USERS`.
    *   Configurer les règles de pare-feu pour permettre le trafic sortant de chaque réseau (`SERVERS net` vers `any`, `USERS net` vers `any`).
    *   Activer la journalisation des blocs par défaut dans pfSense (Status -> System Logs -> Settings).

### 2. Déploiement du Serveur de Gestion (MGMT-Server)

1.  **Créer la VM MGMT-Server (Ubuntu Server) :**
    *   Deux cartes réseau : `LAB_MGMT` (pour communiquer avec pfSense) et `Host-Only Adapter` (pour l'accès SSH depuis l'hôte).
    *   Installer Ubuntu Server (avec OpenSSH Server).
    *   Configurer `rsyslog` pour recevoir les journaux de pfSense (voir section 3.1 du guide détaillé).

### 3. Préparation de l'Environnement d'Automatisation et d'IA

1.  **Accès SSH au MGMT-Server :** Utiliser l'adaptateur Host-Only pour se connecter depuis Windows via SSH (`ssh hero_admin@192.168.56.101`).
2.  **Installer Terraform et Ansible :**
    ```bash
    sudo apt update
    sudo apt install -y unzip curl python3-pip
    curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
    echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
    sudo apt update && sudo apt install terraform
    pip3 install ansible
    ```
3.  **Générer une clé SSH pour pfSense :**
    ```bash
    ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa_pfsense -N ""
    cat ~/.ssh/id_rsa_pfsense.pub
    ```
    Ajouter cette clé publique à l'utilisateur `admin` de pfSense (System -> User Manager -> Users -> admin -> Authorized keys).
4.  **Installer les bibliothèques Python pour l'IA :**
    ```bash
    pip3 install scikit-learn pandas numpy
    ```

### 4. Déploiement IaC avec Terraform (Exemple : Conteneur Docker)

1.  **Créer `~/terraform-lab/main.tf` :**
    ```hcl
    terraform {
      required_providers {
        docker = {
          source  = "kreuzwerker/docker"
          version = "~> 2.15.0"
        }
      }
    }

    provider "docker" {
      host = "unix:///var/run/docker.sock"
    }

    resource "docker_image" "nginx" {
      name         = "nginx:latest"
      keep_locally = true
    }

    resource "docker_container" "web_server" {
      name  = "web_server_tf"
      image = docker_image.nginx.name
      ports {
        internal = 80
        external = 8080
      }
    }
    ```
2.  **Déployer :**
    ```bash
    cd ~/terraform-lab
    terraform init
    terraform apply --auto-approve
    ```

### 5. Gestion de la Configuration avec Ansible (Exemple : Vérification pfSense)

1.  **Créer `~/ansible-lab/hosts.ini` :**
    ```ini
    [firewalls]
    pfsense ansible_host=192.168.1.1 ansible_user=admin ansible_ssh_private_key_file=~/.ssh/id_rsa_pfsense ansible_connection=ssh ansible_python_interpreter=/usr/local/bin/python3
    ```
2.  **Tester la connectivité (module `raw` pour pfSense) :**
    ```bash
    cd ~/ansible-lab
    ansible firewalls -i hosts.ini -m raw -a "uname -a"
    ```

### 6. Détection d'Anomalies par IA en Temps Réel

1.  **Configurer pfSense pour envoyer les journaux :**
    *   Dans le tableau de bord pfSense, allez dans **Status** -> **System Logs** -> **Settings**.
    *   Cochez **"Send log messages to remote syslog server"**.
    *   **Remote log servers :** `192.168.1.100` (IP de votre MGMT-Server).
    *   **Remote Syslog Contents :** Cochez **"Everything"**.
    *   Cochez **"Log packets matched by the default block rule in the main packet filter"**.
    *   Cliquez sur **Save**.
2.  **Créer `~/live_security_ai.py` :**
    ```python
    import time
    import os
    import pandas as pd
    from sklearn.ensemble import IsolationForest

    # 1. SETUP AI MODEL (Training)
    # We train it to know that 1-2 blocks per minute is normal
    df = pd.DataFrame({"blocks": [1, 0, 2, 1, 0, 1, 2, 0, 1, 1]})
    model = IsolationForest(contamination=0.1).fit(df)

    LOG_FILE = "/var/log/pfsense.log"

    print(f"--- LIVE AI WATCHDOG ACTIVE ---")
    print(f"Watching: {LOG_FILE}")

    def monitor_logs():
        # Create the log file if it doesn't exist yet
        if not os.path.exists(LOG_FILE):
            open(LOG_FILE, 'a').close()
            os.chmod(LOG_FILE, 0o666)

        # Open the file and go to the end
        with open(LOG_FILE, "r") as f:
            f.seek(0, 2)
            while True:
                line = f.readline()
                if not line:
                    time.sleep(1)
                    continue
                
                # THE LOGIC: Look for 'filterlog' (pfSense's block log)
                if "filterlog" in line:
                    print(f"[NEW LOG]: {line.strip()[:80]}...")
                    
                    # In a real system, we would count blocks per minute
                    # For this demo, we'll trigger an anomaly if we see a specific pattern
                    # Let's simulate: if we see a log, we treat it as '10' blocks to trigger the AI
                    prediction = model.predict([[10]]) 
                    
                    if prediction[0] == -1:
                        print(">>> !!! AI ALERT: ANOMALOUS TRAFFIC BLOCKED !!!")
                        print(">>> Action: Monitoring source for potential Brute Force.")

    if __name__ == "__main__":
        monitor_logs()
    ```
3.  **Lancer le script AI :**
    ```bash
    sudo python3 ~/live_security_ai.py
    ```
4.  **Déclencher une alerte :** Depuis un autre terminal Ubuntu, lancez `ping -c 4 10.10.10.10`.

## Améliorations Futures Possibles

*   Intégrer un SIEM (ELK Stack ou Splunk) pour une analyse de journaux plus avancée.
*   Développer des playbooks Ansible pour automatiser la réponse aux incidents (par exemple, bloquer une IP source détectée par l'IA).
*   Déployer des services réels (serveur web, base de données) sur le réseau `SERVERS`.
*   Mettre en œuvre un système d'authentification centralisé (par exemple, FreeIPA ou Active Directory) pour les utilisateurs et les serveurs.

## Contact

Pour toute question ou collaboration, n'hésitez pas à me contacter sur [Votre Profil LinkedIn](LIEN_VERS_VOTRE_PROFIL_LINKEDIN).
